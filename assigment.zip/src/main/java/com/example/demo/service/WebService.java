package com.example.demo.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.doa.AirlineInfoDao;
import com.example.demo.doa.BookingRecordDao;
import com.example.demo.doa.FlightDao;
import com.example.demo.doa.PassengerDao;
import com.example.demo.model.AirlineInfo;
import com.example.demo.model.BookingRecord;
import com.example.demo.model.Flight;
import com.example.demo.model.FlightInfo;
import com.example.demo.model.Passenger;

@Service
public class WebService {
	
	@Autowired
	private FlightDao flightDao;
	

	@Autowired
	private PassengerDao passengerDao;
	
	@Autowired
	private BookingRecordDao bookingRecordDao;
	
	@Autowired 
	private AirlineInfoDao airlineInfoDao;
	
	
	
	public List<Flight> getFlightsWithOriginAndDestination(String origin, String destination) {
		return flightDao.findByOriginAndDestination(origin, destination);
	}
	
	public List<Flight> getFlightsWithNumberOriginAndDestination(String flightNumber,String origin, String destination) {
		return flightDao.findByFlightNumberAndOriginAndDestination(flightNumber, origin, destination);
	}
	
	
	
	public Flight getFlightWithDateNumberOriginDestination(String sdate,String flightNumber,String origin, String destination) throws ParseException {
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(sdate);
		
			
		return flightDao.findByFlightDateAndFlightNumberAndOriginAndDestination(date, flightNumber, origin, destination);
	}
	public List<Flight> getSearchedFlights(String origin, String destination, String sdate) throws ParseException 
	{
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(sdate);
		List<Flight> flights=flightDao.findByFlightDateAndOriginAndDestination(date, origin, destination);
		return flights;
		
	}
	public int bookPassengers(int flightId, List<Passenger> passengers) {
		

		Flight flight=flightDao.findById(flightId).get();
		
		Date bookingDate = new Date();  
        Timestamp ts=new Timestamp(bookingDate.getTime()); 
		
		
		
		BookingRecord bookingRecord = new BookingRecord();
		
		bookingRecord.setBookingDate(ts);
		bookingRecord.setDestination(flight.getDestination());
		bookingRecord.setOrigin(flight.getOrigin());
		bookingRecord.setFlightTime(flight.getFlightTime());
		bookingRecord.setFlightNumber(flight.getFlightNumber());
		bookingRecord.setFare(flight.getFare().getFare());
		bookingRecord.setFlightDate(flight.getFlightDate());
		bookingRecord.setStatus("Confirmed");
		List<Passenger>passengers_1= new ArrayList<Passenger>();
		for(Passenger passenger: passengers) {

			passenger.setBookingRecord(bookingRecord);
			passengers_1.add(passenger);
					
		}
		
		
		flight.getInventory().setCount(flight.getInventory().getCount()-1);
		
		flightDao.save(flight);
		passengerDao.saveAll(passengers_1);
		
		return bookingRecord.getId();
		
	}
	
	public int addPassengersToFlight(String[] firstName, String[] lastName,
			String[] mobileNumber,
			String[] gender,int userId, int flightId) {
		
		
		Flight flight=flightDao.findById(flightId).get();
		
		Date bookingDate = new Date();  
        Timestamp ts=new Timestamp(bookingDate.getTime()); 
		
		
		int latestPassengerId= passengerDao.findFirstByOrderByIdDesc().getId();
		int latestBookingRecordId= bookingRecordDao.findFirstByOrderByIdDesc().getId();
		
		BookingRecord bookingRecord = new BookingRecord();
		
		bookingRecord.setBookingDate(ts);
		bookingRecord.setDestination(flight.getDestination());
		bookingRecord.setOrigin(flight.getOrigin());
		bookingRecord.setFlightTime(flight.getFlightTime());
		bookingRecord.setFlightNumber(flight.getFlightNumber());
		bookingRecord.setFare(flight.getFare().getFare());
		bookingRecord.setFlightDate(flight.getFlightDate());
		bookingRecord.setId(latestBookingRecordId+1);
		bookingRecord.setStatus("Confirmed");
		List<Passenger>passengers_1= new ArrayList<Passenger>();
		for(int i=0;i<firstName.length;i++) {
			latestPassengerId++;

			Passenger passenger = new Passenger();
			passenger.setId(latestPassengerId);
			passenger.setFirstName(firstName[i]);
			passenger.setGender(gender[i]);
			passenger.setLastName(lastName[i]);
			passenger.setMobileNumber(Integer.parseInt(mobileNumber[i]));
			passenger.setBookingRecord(bookingRecord);
			passengers_1.add(passenger);
					
		}
		flight.getInventory().setCount(flight.getInventory().getCount()-1);
		
		flightDao.save(flight);
		passengerDao.saveAll(passengers_1);
		
		return bookingRecord.getId();
	}
	public List<BookingRecord> getBookingDetails(int id) {
		List<BookingRecord> record=new ArrayList<BookingRecord>();
		record.add(bookingRecordDao.findById(id).get()); 
		
		return record;
	}
		public List<Flight> getAllFlights(){
		return flightDao.findAll();
	}

}
