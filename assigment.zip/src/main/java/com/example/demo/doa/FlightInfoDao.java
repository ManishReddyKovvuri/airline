package com.example.demo.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.FlightInfo;

public interface FlightInfoDao extends JpaRepository<FlightInfo, Integer> {

	FlightInfo findFirstByOrderByIdDesc();
}
