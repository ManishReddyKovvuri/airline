package com.example.demo.doa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.BookingRecord;

public interface BookingRecordDao extends JpaRepository<BookingRecord, Integer>{
	
	BookingRecord findFirstByOrderByIdDesc();

}
