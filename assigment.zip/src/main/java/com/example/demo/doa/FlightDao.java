package com.example.demo.doa;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Flight;

public interface FlightDao extends JpaRepository<Flight, Integer>{
	
	List<Flight> findByFlightDate(Date date);
	
	List<Flight> findByFlightDateAndOrigin(Date date,String origin);
	Flight findByFlightDateAndFlightNumberAndFlightTime(Date date, String flightNumber, Time flightTime );
	
	List<Flight> findByFlightDateAndOriginAndDestination(Date date,String origin,String destination);
	List<Flight> findByOriginAndDestination(String origin,String destination);
	
	List<Flight> findByFlightNumberAndOriginAndDestination(String flightNumber,String origin,String destination);
	
	Flight findByFlightDateAndFlightNumberAndOriginAndDestination(Date date,String flightNumber,String origin,String destination);
	
	Flight findFirstByOrderByIdDesc();
	
	Flight findByFlightDateAndOriginAndDestinationAndFlightTime(Date date,String origin,String destination,Time time);
	List<Flight> findByFlightDateNot(Date date);

//	@Query(value="from Flight  where flight_infoid = :flightInfoID")
//	Flight findFlightByFlightInfoID(Integer flightInfoID);
	
	

}
