package com.example.demo.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Fare;

public interface FareDao extends JpaRepository<Fare, Integer>{
	
	Fare findFirstByOrderByIdDesc();

}
