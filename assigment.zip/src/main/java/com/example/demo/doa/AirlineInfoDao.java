package com.example.demo.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.AirlineInfo;

public interface AirlineInfoDao extends JpaRepository<AirlineInfo, Integer> {
	
	 AirlineInfo findByAirlineName(String name);
	 
	 
	 

}
