package com.example.demo.controller;




import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.doa.FlightDao;
import com.example.demo.doa.UserDao;
import com.example.demo.model.BookingRecord;
import com.example.demo.model.Loginform;
import com.example.demo.model.User;
import com.example.demo.service.WebService;

@org.springframework.stereotype.Controller
public class Controller {
	
	@Autowired
	private WebService flightService;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private FlightDao flightDao;
	
	private int flightId;
	private int userId;
	
	
	
	@RequestMapping(value="/", produces = MediaType.TEXT_HTML_VALUE)
	public String welcome() {
		return "home";
	}
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
	
	@RequestMapping("/loginFail")
	public String loginFail(Model model) {
		return "index";
	}
	
	@RequestMapping("/SignUp")
	public String signUp(Model model) {
		return "SignUp";
	}
	
	
	@RequestMapping("/loginr")
	public String validateLogin(Model model,@RequestParam(value = "userName")String userName, 
			@RequestParam(value = "password")String password  ) {
		
		Loginform loginForm= new Loginform(userName, password);
		String result= validateLogin(loginForm);
		
		if(result.equals("User not found")) {
			model.addAttribute("reason",result);
			return "loginFail";
		}else {
			userId=userDao.findByUserName(userName).getId();
			return "SearchFlights";
		}
		
		
	}
	@RequestMapping("/FindFlights")
	public String searchFlights(@RequestParam(value = "origin")String origin,
								@RequestParam(value = "destination")String destination,
								@RequestParam(value = "date")String date,Model model) throws ParseException {
		
		model.addAttribute("flights", flightService.getSearchedFlights(origin, destination, date));
		return"ShowFlights";
		
	}
	
	@RequestMapping("/BookFlight")
	public String bookFlight(@RequestParam(value = "id")int id,Model model) {
		flightId=id;
		model.addAttribute("flight", flightDao.findById(id).get());
		return"BookFlight";
		
	}
	
	@RequestMapping("/reserve")
	public String demo(@RequestParam(value="firstName")String[] firstName, @RequestParam(value="lastName")String[] lastName,
			@RequestParam(value="mobileNumber")String[] mobileNumber,
			@RequestParam(value="gender")String[] gender, Model model) {
		int id =flightService.addPassengersToFlight(firstName, lastName, mobileNumber, gender,userId,flightId);
		model.addAttribute("bookingId",id);
		return "ShowBookingId";
		
	}
	@RequestMapping("/addPassengers")
	public String addPassengers(@RequestParam(value = "passengers")int numOfPassengers,Model model) {
		List<Integer> list= new ArrayList<Integer>();
		for(int i=0 ;i<numOfPassengers;i++) {list.add(i);}
		model.addAttribute("numberof", list);
		
		return "Addpassenger";
	}
	
	@RequestMapping("/addUser")
	public String addUser(User userDetails) {
		userDao.save(userDetails);
		return"index";
		
	}
	
	@RequestMapping("/status")
	private String checkStatus() {
		return "BookingStatus";
	}
	
	@RequestMapping("/openBooking")
	private String openBooking(@RequestParam(value="bookingId" )int id,Model model) {
		List<BookingRecord> record=  flightService.getBookingDetails(id);
		model.addAttribute("record", record);
		model.addAttribute("passengers", record.get(0).getPassengers());
		return "DisplayBooking";
	}
	
	

	@RequestMapping(value = "/flights")
	public String findAllFlights(Model model){
		model.addAttribute("flights", flightService.getAllFlights());
		return "flights";
	}
	
	
	
	private  String validateLogin(Loginform loginForm) {
		
		try {
		User user= userDao.findByUserName(loginForm.getUserName());
		if(loginForm.getPassword().equals(user.getPassword())) {
			return "User Found";
		}else {
			return "Incorrect credentials";
		}
		
		}
		catch (NullPointerException e) {

			return "User not found";
			
			
		}
	}	
}
