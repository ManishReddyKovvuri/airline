package com.example.demo.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.doa.UserDao;
import com.example.demo.model.BookingRecord;
import com.example.demo.model.Flight;
import com.example.demo.model.Loginform;
import com.example.demo.model.Passenger;
import com.example.demo.model.User;
import com.example.demo.service.WebService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class AirlineRestController {
	
	
	@Autowired
	private WebService webService;
	
	@Autowired
	private UserDao userDao;
	
	
	@RequestMapping(value="/Login", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
	        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, method = RequestMethod.GET)
	public String login(@RequestBody Loginform loginForm) throws JsonProcessingException {
		String result= validateLogin(loginForm);
		ObjectMapper mapper = new ObjectMapper();
	      String jsonString = mapper.writeValueAsString(result);
		return jsonString;
		
	}
	

	
	private  String validateLogin(Loginform loginForm) {
		
		try {
		User user= userDao.findByUserName(loginForm.getUserName());
		if(loginForm.getPassword().equals(user.getPassword())) {
			return "User Found";
		}else {
			return "Incorrect credentials";
		}
		
		}
		catch (NullPointerException e) {

			return "User not found";
			
			
		}
	}
	@RequestMapping(value="/Search", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
	        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, method = RequestMethod.GET)
	public List<Flight> search(@RequestBody Map<String, Object> payload) throws ParseException {

		List<Flight> flights =getFlightsFromMap(payload);
		
		return flights;
		
	}
	
	
	@RequestMapping(value="/Book", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
	        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, method = RequestMethod.POST)
	public String  book(@RequestBody Map<String, Object> payload) throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		
		 String jsonString = objectMapper.writeValueAsString(payload.get("passengers"));
		List<Passenger> passengers = objectMapper.readValue(jsonString, new TypeReference<List<Passenger>>(){});
		int flightId= (int)payload.get("flightId");
		
		 return ("Booking ID : "+webService.bookPassengers(flightId, passengers));
		
		
	}
	
	@RequestMapping(value="/check", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
	        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, method = RequestMethod.GET)
	public BookingRecord check(@RequestBody Map<String, Object> payload) {
		BookingRecord record= webService.getBookingDetails((int)payload.get("bookingId")).get(0);
		for(Passenger p:record.getPassengers()) {
			p.setBookingRecord(null);
		}
		return record;
		
	}
	

	private List<Flight> getFlightsFromMap(Map<String, Object> payload) throws ParseException {
		String origin= (String) payload.get("origin");
		String destination= (String) payload.get("destination");
		String stringDate = (String) payload.get("date");
		String flightNumber= (String) payload.get("flightnumber");
		List<Flight> flights= new ArrayList<Flight>();
		
		
		if (stringDate==null) {
			if(flightNumber==null || flightNumber.isBlank()) {
				System.out.println(1);
				flights.addAll(webService.getFlightsWithOriginAndDestination(origin, destination));
				
			}else {
				System.out.println(2);
				flights.addAll(webService.getFlightsWithNumberOriginAndDestination(flightNumber, origin, destination));
			}
		}else {
			if(flightNumber==null || flightNumber.isBlank()) {
				System.out.println(3);
				flights.addAll (webService.getSearchedFlights(origin, destination, stringDate));
				
			}else {
				System.out.println(4);
				flights.add(webService.getFlightWithDateNumberOriginDestination(stringDate, flightNumber, origin, destination));
				
			}
			
		}
		return flights;
	}
	

}


